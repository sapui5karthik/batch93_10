sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller,ODataModel,JSONModel,MessageToast) {
	"use strict";

	return Controller.extend("zsapui5proj06sapwithpanelsZSAPUI5_Proj06_SAPWithPanels.controller.SAPData", {
	onInit : function(){
		
		var sapdata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
		//SAP ProductSet
		var sapproductodatamodel = new ODataModel(sapdata);
		var sapproductjsonmodel = new JSONModel();
		sap.ui.core.BusyIndicator.show(0);
		
		sapproductodatamodel.read("/ProductSet",{
			success : function(req,resp){ 
				sap.ui.core.BusyIndicator.hide();
				sapproductjsonmodel.setSizeLimit(1000);
				sapproductjsonmodel.setData(req.results);
				this.getView().byId("producttable").setModel(sapproductjsonmodel,"sapprod");
			}.bind(this),
			error : function(msg){
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Failed:1000:" + msg);
			}
		});
		
	}, // end of onInit

	_panel2 : function(){
		//this.byId("panel2").mProperties.expanded;	//usage of private memebers are not allowed
	
		if(this.byId("panel2").getExpanded()){
			this.byId("panel1").setExpanded(false);
		var sapdata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
		//SAP ProductSet
		var sapbuspartodatamodel = new ODataModel(sapdata);
		var sapbuspartjsonmodel = new JSONModel();
		sap.ui.core.BusyIndicator.show(0);
		
		sapbuspartodatamodel.read("/BusinessPartnerSet",{
			success : function(req,resp){ 
				sap.ui.core.BusyIndicator.hide();
				sapbuspartjsonmodel.setSizeLimit(1000);
				sapbuspartjsonmodel.setData(req.results);
				this.getView().byId("busparttable").setModel(sapbuspartjsonmodel,"sapbp");
			}.bind(this),
			error : function(msg){
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Failed:1001:" + msg);
			}
		});
		}
	}, //end of _panel2
	
	
	_panel3 : function(){
		if(this.byId("panel3").getExpanded()){
			
		var sapdata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
		//SAP ProductSet
		var sapvhcountryodatamodel = new ODataModel(sapdata);
		var sapvhcountryjsonmodel = new JSONModel();
		sap.ui.core.BusyIndicator.show(0);
		
		sapvhcountryodatamodel.read("/VH_CountrySet",{
			success : function(req,resp){ 
				sap.ui.core.BusyIndicator.hide();
				sapvhcountryjsonmodel.setSizeLimit(1000);
				sapvhcountryjsonmodel.setData(req.results);
				this.getView().byId("vhcountrytable").setModel(sapvhcountryjsonmodel,"sapvhcountry");
			}.bind(this),
			error : function(msg){
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Failed:1002:" + msg);
			}
		});
		
			
		}
	}, //end of _panel3
	
	
	
	
	
	
	});
});