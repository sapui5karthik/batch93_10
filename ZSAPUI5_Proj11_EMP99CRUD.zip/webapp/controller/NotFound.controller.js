sap.ui.define([
		"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("zsapui5proj11emp99crud.ZSAPUI5_Proj11_EMP99CRUD.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);