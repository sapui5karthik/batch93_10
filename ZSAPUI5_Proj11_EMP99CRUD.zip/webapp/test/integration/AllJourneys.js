/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/pages/Worklist",
	"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/pages/Object",
	"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/pages/NotFound",
	"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/pages/Browser",
	"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zsapui5proj11emp99crud.ZSAPUI5_Proj11_EMP99CRUD.view."
	});

	sap.ui.require([
		"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/WorklistJourney",
		"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/ObjectJourney",
		"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/NavigationJourney",
		"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/NotFoundJourney",
		"zsapui5proj11emp99crud/ZSAPUI5_Proj11_EMP99CRUD/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});