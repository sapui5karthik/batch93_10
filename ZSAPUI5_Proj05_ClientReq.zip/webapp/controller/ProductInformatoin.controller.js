sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller,ODataModel,JSONModel,MessageToast) {
	"use strict";

	return Controller.extend("zsapui5proj05clientreqZSAPUI5_Proj05_ClientReq.controller.ProductInformatoin", {
		onInit : function(){
			
		var sapdata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
		var sapodatamodel = new ODataModel(sapdata);
		var sapjsonmodel = new JSONModel();
		sap.ui.core.BusyIndicator.show(0);
		sapodatamodel.read("/ProductSet",{
			success : function(req,resp){
				sap.ui.core.BusyIndicator.hide();
				sapjsonmodel.setSizeLimit(1000);
				sapjsonmodel.setData(req.results);
				this.getView().byId("sapproductstable").setModel(sapjsonmodel);
			}.bind(this),
			error : function(msg){
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Failed:1000:" + msg);
			}
		});
		
			
		}
	});
});