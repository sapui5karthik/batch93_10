sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller,ODataModel,JSONModel,MessageToast) {
	"use strict";

	return Controller.extend("zsapui5proj06sapwithpanelsZSAPUI5_Proj06_SAPWithPanels.controller.SAPData", {
	onInit : function(){
		var sapdata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
		//SAP ProductSet
		var sapproductodatamodel = new ODataModel(sapdata);
		var sapproductjsonmodel = new JSONModel();
		sap.ui.core.BusyIndicator.show(0);
		sapproductodatamodel.read("/ProductSet",{
			success : function(req,resp){ 
				sap.ui.core.BusyIndicator.hide();
				sapproductjsonmodel.setSizeLimit(1000);
				sapproductjsonmodel.setData(req.results);
				this.getView().byId("producttable").setModel(sapproductjsonmodel,"sapprod");
			}.bind(this),
			error : function(msg){
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Failed:1000:" + msg);
			}
		});
	}
	});
});