sap.ui.define([
	] , function () {
		"use strict";

		return {
			
			width1 : function(w1){
				if(!w1){
					return "";
				}
				return parseFloat(w1).toFixed(6);
			},
			discprice1 : function(dp1){
				if(dp1 === ""){
					return "";
				}
				if(dp1 < 4){
					return dp1 - 1;
				}
				if(dp1 >=4 && dp1 <= 7){
					return dp1 - 2;
				}
				if(dp1 > 7){
					return dp1 - 3;
				}
			},
			pricecolor : function(p1){
				if(p1 < 4){
					return "Success";
				}
				if(p1 >=4 && p1 <= 7){
					return "Warning";
				}
				if(p1 > 7){
					return "Error";
				}
			},
			createddate1 : function(d1){
				
				var d2 = sap.ui.core.format.DateFormat.getDateInstance({
					pattern : "yyyy-MM-dd"
					});
				
				return d2.format(new Date(d1));
			},//end of createddate1

			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			}

		};

	}
);