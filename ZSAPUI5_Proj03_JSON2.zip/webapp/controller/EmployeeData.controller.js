sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("zsapui5proj03json2ZSAPUI5_Proj03_JSON2.controller.EmployeeData", {

	onInit : function(){
		
	var data = {
	
		"emaxemp" :	[
				{"EMPID":100,"EMPNAME":"Renuka","EMPDES":"UI5 Dev","WFH":true,"rating":4.5,"gender":"./images/femaleicon.jpg"},
				{"EMPID":101,"EMPNAME":"Hemanth","EMPDES":"UI5 Lead","WFH":false,"rating":3,"gender":"./images/maleicon.jpg"},
				{"EMPID":102,"EMPNAME":"Srinu","EMPDES":"Lead ABAPer","WFH":true,"rating":4,"gender":"./images/maleicon.jpg"},
				{"EMPID":103,"EMPNAME":"Karthik","EMPDES":"Trainer","WFH":false,"rating":2,"gender":"./images/maleicon.jpg"},
				{"EMPID":104,"EMPNAME":"Ram","EMPDES":"Trainer","WFH":false,"rating":1,"gender":"./images/maleicon.jpg"},
				{"EMPID":105,"EMPNAME":"Deepak","EMPDES":"Trainer","WFH":false,"rating":2.3,"gender":"./images/maleicon.jpg"},
				{"EMPID":106,"EMPNAME":"James","EMPDES":"Trainer","WFH":true,"rating":4.5,"gender":"./images/maleicon.jpg"},
				{"EMPID":107,"EMPNAME":"Mary","EMPDES":"Trainer","WFH":false,"rating":2,"gender":"./images/femaleicon.jpg"},
				{"EMPID":108,"EMPNAME":"Ravi","EMPDES":"Trainer","WFH":true,"rating":2,"gender":"./images/maleicon.jpg"}
			]
	};
		
	var jsonmodel = new sap.ui.model.json.JSONModel();
	jsonmodel.setData(data);
	this.getView().byId("table1").setModel(jsonmodel);
		
	}//end of onInit



	});
});