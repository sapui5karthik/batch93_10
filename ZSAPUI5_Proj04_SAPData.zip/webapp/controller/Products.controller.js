sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("zsapui5proj04sapdataZSAPUI5_Proj04_SAPData.controller.Products", {
		
		onInit : function(){
			var data = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel = new sap.ui.model.odata.ODataModel(data);
			var jsonmodel = new sap.ui.model.json.JSONModel();
			//this.byId("table1").setBusy(true);
			sap.ui.core.BusyIndicator.show(0);
			odatamodel.read("/ProductSet",{
				success : function(req,resp){
					sap.ui.core.BusyIndicator.hide();
					//this.byId("table1").setBusy(false);
					jsonmodel.setSizeLimit(1000);
					jsonmodel.setData(req.results);
					this.getView().byId("table1").setModel(jsonmodel);
				
				}.bind(this),
				error : function(msg){
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("Failed/Retry:1000:" + msg);
				}
			});
		
		}
		
	});
});